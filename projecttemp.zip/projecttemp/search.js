// Include form validation functions here
const movies=[

{name:'Avatar',box:'$2,787,965,087',active: 'Yes',dateOfLaunch:'15/03/2017',Genre:'Science Fiction',hasTeaser:'yes'},
{name:'The Avengers',box:'$2,787,965,087',active: 'Yes',dateOfLaunch:'23/12/2017',Genre:'Super hero',hasTeaser:'no'},
{name:'Titanic',box:'$2,787,965,087',active: 'Yes',dateOfLaunch:'15/03/2017',Genre:'Romance',hasTeaser:'no'},
{name:'Jurassic World',box:'$2,787,965,087',active: 'No',dateOfLaunch:'15/03/2017',Genre:'Science Fiction',hasTeaser:'yes'},
{name:'Avengers:End Game',box:'$2,787,965,087', active: 'Yes',dateOfLaunch:'15/03/2017',Genre:'Science Fiction',hasTeaser:'yes'},

];

const renderProducts=function(movies)

{

let tabEl=document.querySelector("#mov-tab");

movies.forEach(function(movie){

let trEl1=document.createElement("tr");

let tdEl1=document.createElement("td");

tdEl1.textContent=movie.name;

trEl1.appendChild(tdEl1);

let tdEl2=document.createElement("td");

tdEl2.textContent=movie.box;

trEl1.appendChild(tdEl2);

let tdEl3=document.createElement("td");

tdEl3.textContent=movie.active;

trEl1.appendChild(tdEl3);

let tdEl4=document.createElement("td");

tdEl4.textContent=movie.dateOfLaunch;

trEl1.appendChild(tdEl4);

let tdEl5=document.createElement("td");

tdEl5.textContent=movie.Genre;

trEl1.appendChild(tdEl5);

let tdEl6=document.createElement("td");

tdEl6.textContent=movie.hasTeaser;

trEl1.appendChild(tdEl6);

tabEl.appendChild(trEl1);

let tdEl7=document.createElement("td");

let editLink=document.createElement('a');

editLink.setAttribute('id','link1');

editLink.href="edit-movie.html";

editLink.textContent="Edit"

tdEl7.appendChild(editLink);

trEl1.appendChild(tdEl7);
document.querySelector('#link1').addEventListener('click',function(){
	 document.getElementById("#name").value = movie.name;


	})

})



}

renderProducts(products);

