import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent { 
    
    table1=[{name:'were',age:20},{name:'qwerty',age:15},{name:'hima',age:21},{name:'diana',age:21}];
}
